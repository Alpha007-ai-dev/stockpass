// Az amerikai tőzsde állapota New York-i idő szerint.
// Nyári időszámítás: március 2. vasárnapja → november 1. vasárnapja.
// Egyszerűsítés: az amerikai tőzsdei ünnepnapokat még nem kezeli.

export type MarketState = 'open' | 'pre' | 'after' | 'closed'

function nthSunday(year: number, month: number, n: number): number {
  const firstDow = new Date(Date.UTC(year, month, 1)).getUTCDay()
  return 1 + ((7 - firstDow) % 7) + (n - 1) * 7
}

function nyOffsetHours(d: Date): number {
  const y = d.getUTCFullYear()
  const dstStart = Date.UTC(y, 2, nthSunday(y, 2, 2), 7) // 02:00 EST = 07:00 UTC
  const dstEnd = Date.UTC(y, 10, nthSunday(y, 10, 1), 6) // 02:00 EDT = 06:00 UTC
  const t = d.getTime()
  return t >= dstStart && t < dstEnd ? -4 : -5
}

export function getMarketState(now: Date = new Date()): MarketState {
  // A UTC-getterek itt New York-i helyi időt adnak vissza.
  const ny = new Date(now.getTime() + nyOffsetHours(now) * 3_600_000)
  const dow = ny.getUTCDay()
  const mins = ny.getUTCHours() * 60 + ny.getUTCMinutes()

  if (dow === 0 || dow === 6) return 'closed'
  if (mins >= 9 * 60 + 30 && mins < 16 * 60) return 'open'
  if (mins >= 4 * 60 && mins < 9 * 60 + 30) return 'pre'
  if (mins >= 16 * 60 && mins < 20 * 60) return 'after'
  return 'closed'
}

export const MARKET_LABEL: Record<MarketState, { title: string; subtitle: string }> = {
  open: { title: 'US MARKET OPEN', subtitle: 'Tokens and shares trading side by side' },
  pre: { title: 'PRE-MARKET', subtitle: 'Regular session closed · tokens still trading' },
  after: { title: 'AFTER-HOURS', subtitle: 'Regular session closed · tokens still trading' },
  closed: { title: 'US MARKET CLOSED', subtitle: 'Wall Street is closed · tokenized stocks are still moving' },
}
